package com.example.flutter_application_spacex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
