import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

void main() {
  initializeDateFormatting().then((_) {
    runApp(SpaceXLaunchApp());
  });
}

class SpaceXLaunchApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SpaceX LANZAMIENTOS REGISTRADOS',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LaunchScreen(),
    );
  }
}

class Launch {
  final String missionName;
  final DateTime launchDate;
  final String status;
  final String? rocketImage;

  Launch({
    required this.missionName,
    required this.launchDate,
    required this.status,
    required this.rocketImage,
  });

  factory Launch.fromJson(Map<String, dynamic> json) {
    return Launch(
      missionName: json['Nombre'],
      launchDate: DateTime.parse(json['date_utc']),
      status: json['EXITO!!!'] == null
          ? 'Siguienge'
          : (json['EXITO'] ? 'EXITO' : 'FRACASADO'),
      rocketImage: json['links']['patch']['large'],
    );
  }
}

class LaunchScreen extends StatefulWidget {
  @override
  _LaunchScreenState createState() => _LaunchScreenState();
}

class _LaunchScreenState extends State<LaunchScreen> {
  late Future<List<Launch>> upcomingLaunches;

  @override
  void initState() {
    super.initState();
    upcomingLaunches = fetchLaunches();
  }

  Future<List<Launch>> fetchLaunches() async {
    final response =
        await http.get(Uri.parse('https://api.spacexdata.com/v4/launches'));

    if (response.statusCode == 200) {
      List<dynamic> data = json.decode(response.body);
      return data.map((json) => Launch.fromJson(json)).toList();
    } else {
      throw Exception('Error de lanzamientos');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('SpaceX Lanzamientos registrados:'),
      ),
      body: FutureBuilder<List<Launch>>(
        future: upcomingLaunches,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('Ningun lanzamiento encontrado'));
          }

          List<Launch> launches = snapshot.data!;
          return ListView.builder(
            itemCount: launches.length,
            itemBuilder: (context, index) {
              return LaunchCard(launch: launches[index]);
            },
          );
        },
      ),
    );
  }
}

class LaunchCard extends StatelessWidget {
  final Launch launch;

  LaunchCard({required this.launch});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10.0),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              launch.missionName,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
                'Fecha de lanzamiento: ${DateFormat.yMMMd().format(launch.launchDate)}'),
            SizedBox(height: 10),
            Text('Status: ${launch.status}'),
            SizedBox(height: 10),
            launch.rocketImage != null && launch.rocketImage!.isNotEmpty
                ? Image.network(
                    launch.rocketImage!,
                    errorBuilder: (BuildContext context, Object exception,
                        StackTrace? stackTrace) {
                      return Container(
                        height: 100,
                        color: Colors.grey,
                        child: Center(
                          child: Text('Imagen no encontrada'),
                        ),
                      );
                    },
                  )
                : Container(
                    height: 100,
                    color: Colors.grey,
                    child: Center(
                      child: Text('Imagen no encotrada'),
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}
